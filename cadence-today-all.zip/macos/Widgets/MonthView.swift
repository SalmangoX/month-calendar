import AppIntents
import SwiftUI
import WidgetKit

/// 整月小组件：只显示本月的日期，周数按月份 4–6 行；当前周高一些，垫一块淡淡的中性灰底。颜色和网页一致。
/// 格子够高时显示色条（跨天的全天事件画成一整条），矮时显示彩色圆点，再矮只显示日期。
struct MonthView: View {
    let entry: CalEntry

    /// 尺寸：中尺寸用紧凑一档
    private struct Metrics {
        let topPad: CGFloat, headH: CGFloat, wdH: CGFloat, bottomPad: CGFloat, side: CGFloat
        let cellTop: CGFloat, dateH: CGFloat, dateFont: CGFloat
        let chipH: CGFloat = 14, slot: CGFloat = 15.5
        init(compact: Bool) {
            topPad = compact ? 4 : 6; headH = compact ? 24 : 30; wdH = compact ? 14 : 18; bottomPad = compact ? 4 : 6
            side = compact ? 4 : 5; cellTop = compact ? 1 : 3; dateH = compact ? 16 : 18; dateFont = compact ? 11 : 12
        }
        /// 每格能放几条事件：≥1 显示色条；0 显示圆点；-1 只显示日期。当前周高一些，最多放 4 条
        func capacity(_ rowH: CGFloat, current: Bool) -> Int {
            let room = rowH - cellTop - dateH
            let cap = Int(((room - 1) / slot).rounded(.down))
            if cap >= 1 { return min(cap, current ? 4 : 3) }
            return room >= 8 ? 0 : -1
        }
    }

    /// 当前周比其他周高 30%
    private static let curWeight: CGFloat = 1.3

    var body: some View {
        WidgetShell { pal in
            GeometryReader { g in
                let W = g.size.width, H = g.size.height
                let m = Metrics(compact: H < 220)
                let today = entry.today
                let ym = today.firstOfMonth.addingMonths(entry.moff)
                let days = monthGrid(ym, weekStart: entry.weekStart)
                let rows = (days.lastIndex { $0.m == ym.m } ?? 34) / 7 + 1
                let cur: Int? = today.y == ym.y && today.m == ym.m ? days.firstIndex(of: today).map { $0 / 7 } : nil
                let gridH = H - m.topPad - m.headH - m.wdH - m.bottomPad
                let unit = gridH / (CGFloat(rows) + (cur == nil ? 0 : MonthView.curWeight - 1))
                let cw = (W - 2 * m.side) / 7
                VStack(spacing: 0) {
                    header(ym, pal, m)
                    HStack(spacing: 0) {
                        ForEach(0..<7, id: \.self) { k in
                            Text(I18n.wdHead((k + entry.weekStart) % 7)).font(.system(size: m.wdH > 15 ? 10 : 9))
                                .foregroundStyle(pal.text2).frame(width: cw)
                        }
                    }
                    .frame(height: m.wdH)
                    VStack(spacing: 0) {
                        ForEach(0..<rows, id: \.self) { r in
                            week(Array(days[r * 7..<r * 7 + 7]), ym: ym, today: today, cw: cw,
                                 rowH: unit * (r == cur ? MonthView.curWeight : 1), current: r == cur, pal: pal, m: m)
                                .overlay(alignment: .top) {
                                    // 周与周之间一条细线；当前周上下不画
                                    if r > 0 && r != cur && r - 1 != cur { pal.line.frame(height: 0.5).padding(.horizontal, 6) }
                                }
                        }
                    }
                }
                .padding(.horizontal, m.side)
                .padding(.top, m.topPad)
            }
        }
    }

    private func header(_ ym: YMD, _ pal: Pal, _ m: Metrics) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 0) {
            Text(I18n.mon(ym.m)).font(.system(size: m.headH > 26 ? 16 : 14, weight: .bold)).foregroundStyle(pal.text).widgetAccentable()
            Text(String(ym.y)).font(.system(size: 11)).foregroundStyle(pal.text2).padding(.leading, 6)
            Spacer(minLength: 0)
            if entry.moff != 0 {
                Button(intent: ShiftMonthIntent(delta: 0)) {
                    Text(I18n.t("本月")).font(.system(size: 11, weight: .semibold)).foregroundStyle(pal.text2)
                        .padding(.horizontal, 8).frame(height: m.headH).contentShape(Rectangle())
                }
                .buttonStyle(.plain).widgetAccentable()
            }
            ForEach([-1, 1], id: \.self) { k in
                Button(intent: ShiftMonthIntent(delta: k)) {
                    Image(systemName: k < 0 ? "chevron.left" : "chevron.right")
                        .font(.system(size: 11, weight: .semibold)).foregroundStyle(pal.text2)
                        .frame(width: 32, height: m.headH).contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.leading, 8)
        .frame(height: m.headH)
    }

    @ViewBuilder
    private func week(_ wk: [YMD], ym: YMD, today: YMD, cw: CGFloat, rowH: CGFloat, current: Bool, pal: Pal, m: Metrics) -> some View {
        let d = entry.data
        let inM = wk.map { $0.m == ym.m }
        let cap = m.capacity(rowH, current: current)
        // 只排本月的日子：跨月的事件在月份边界处截断（那一端是平的）
        let lay = WeekLanes.lay((0..<7).map { inM[$0] ? d.on(wk[$0]) : [] })
        let lim = (0..<7).map { inM[$0] ? min(lay.occ[$0].count, max(cap, 0)) : 0 }
        let segs = cap >= 1 ? lay.segments(lim, week0: wk[0]) : []
        ZStack(alignment: .topLeading) {
            if current { band(pal).frame(width: cw * 7, height: rowH) }
            HStack(spacing: 0) {
                ForEach(0..<7, id: \.self) { k in
                    cell(wk[k], inMonth: inM[k], occ: lay.occ[k], lim: lim[k], today: today, cap: cap, cw: cw, current: current, pal: pal, m: m)
                        .frame(width: cw, height: rowH, alignment: .topLeading)
                }
            }
            ForEach(Array(segs.enumerated()), id: \.offset) { _, s in bar(s, cw: cw, pal: pal, m: m) }
        }
        .frame(width: cw * 7, height: rowH, alignment: .topLeading)
    }

    /// 当前周：一块平的淡灰底，没有渐变、描边和阴影
    private func band(_ pal: Pal) -> some View {
        RoundedRectangle(cornerRadius: 11, style: .continuous).fill(pal.weekBand).padding(.vertical, 1.5)
    }

    @ViewBuilder
    private func cell(_ day: YMD, inMonth: Bool, occ: [WeekLanes.Slot], lim: Int, today: YMD, cap: Int, cw: CGFloat, current: Bool, pal: Pal, m: Metrics) -> some View {
        if !inMonth {
            Color.clear // 只显示本月
        } else {
            let d = entry.data
            let isToday = day == today
            let hidden = cap >= 1 ? occ.dropFirst(lim).filter { !$0.isEmpty }.count : 0
            let dots = cap == 0 ? Array(d.on(day).filter { !$0.done }.prefix(3)) : []
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 0) {
                    // 今天：和网页一样，淡主色圆 + 主色字
                    Text("\(day.d)")
                        .font(.system(size: m.dateFont, weight: isToday ? .semibold : .regular))
                        .foregroundStyle(isToday ? pal.accentText : pal.text)
                        .frame(width: m.dateH + 3, height: m.dateH + 3)
                        .background { if isToday { Circle().fill(pal.todayDim).widgetAccentable() } }
                        .frame(height: m.dateH)
                        .padding(.leading, 1)
                    Spacer(minLength: 0)
                    if hidden > 0 {
                        Text("+\(hidden)").font(.system(size: 8.5)).foregroundStyle(pal.text2).padding(.trailing, 3).lineLimit(1)
                    }
                }
                .frame(height: m.dateH)
                if cap >= 1 {
                    ForEach(0..<lim, id: \.self) { s in
                        switch occ[s] {
                        case .event(let e): chip(e, width: cw - 3, pal: pal, m: m)
                        default: Color.clear.frame(height: m.chipH) // 占位，让下面的事件和横条对齐
                        }
                    }
                    .padding(.top, m.slot - m.chipH)
                } else if !dots.isEmpty {
                    HStack(spacing: 2.5) {
                        ForEach(Array(dots.enumerated()), id: \.offset) { _, e in
                            Circle().fill(Color(argb: pal.base(e, d))).frame(width: 5, height: 5)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.top, 2)
                }
            }
            .padding(.top, m.cellTop)
        }
    }

    private func chip(_ e: CEvent, width: CGFloat, pal: Pal, m: Metrics) -> some View {
        let (fill, ink) = pal.chip(e, entry.data, soft: e.done)
        return Text(e.displayTitle)
            .font(.system(size: 9.5, weight: pal.dark ? .medium : .semibold))
            .tracking(-0.24)
            .strikethrough(e.done)
            .foregroundStyle(ink)
            .lineLimit(1)
            .fixedSize()
            .padding(.leading, 2.5)
            .frame(width: width, height: m.chipH, alignment: .leading)
            .clipped()
            .background(RoundedRectangle(cornerRadius: 4.5, style: .continuous).fill(fill))
            .padding(.horizontal, 1.5)
            .widgetAccentable()
    }

    /// 跨天横条：和格子里的色条同样的颜色、圆角、字号；延续到别的周（或别的月）的一端是平的
    private func bar(_ s: WeekLanes.Seg, cw: CGFloat, pal: Pal, m: Metrics) -> some View {
        let (fill, ink) = pal.chip(s.e, entry.data, soft: s.e.done)
        let x0 = CGFloat(s.a) * cw + (s.openL ? 0 : 1.5)
        let x1 = CGFloat(s.b + 1) * cw - (s.openR ? 0 : 1.5)
        let y = m.cellTop + m.dateH + (m.slot - m.chipH) + CGFloat(s.slot) * m.slot
        let rl: CGFloat = s.openL ? 0 : 4.5, rr: CGFloat = s.openR ? 0 : 4.5
        return Text(s.e.displayTitle)
            .font(.system(size: 9.5, weight: pal.dark ? .medium : .semibold))
            .tracking(-0.24)
            .strikethrough(s.e.done)
            .foregroundStyle(ink)
            .lineLimit(1)
            .fixedSize()
            .padding(.leading, 4)
            .frame(width: max(0, x1 - x0), height: m.chipH, alignment: .leading)
            .clipped()
            .background(UnevenRoundedRectangle(topLeadingRadius: rl, bottomLeadingRadius: rl, bottomTrailingRadius: rr, topTrailingRadius: rr, style: .continuous).fill(fill))
            .widgetAccentable()
            .offset(x: x0, y: y)
    }
}
